//
//  RestaurentCellViewModel.swift
//  TableView
//
//  Created by PCI0010 on 12/25/18.
//  Copyright © 2018 Hai Nguyen H.P. All rights reserved.
//

import Foundation
import UIKit

final class RestaurentCellViewModel {
    
    // MARK: - PROPERTIES
    private var caffe: Caffe?
    var image: UIImage?
    var distance = ""
    var rating = ""
    var title = ""
    var address = ""
    var isFavorite: Bool = false {
        didSet {
            guard let caffe = caffe else { return }
            caffe.isFavorite = isFavorite
        }
    }
    
    // MARK: - INIT
    init(caffe: Caffe) {
        self.caffe = caffe
        distance = caffe.distance
        rating = caffe.rating
        title = caffe.title
        address = caffe.address
        isFavorite = caffe.isFavorite
        image = caffe.image
    } 
}
