//
//  RestaurentCellTableViewCell.swift
//  TableView
//

import UIKit

final class RestaurentCellTableViewCell: UITableViewCell {

    // MARK: - OUTLET
    @IBOutlet private weak var distanceLabel: UILabel!
    @IBOutlet private weak var favoriteButton: UIButton!
    @IBOutlet private weak var ratingLabel: UILabel!
    @IBOutlet private weak var addressLabel: UILabel!
    @IBOutlet private weak var titleLabel: UILabel!
    @IBOutlet private weak var avatarImageView: UIImageView!

    // MARK: - PROPERTIES
    var viewModel: RestaurentCellViewModel? {
        didSet {
            updateView()
        }
    }
    
    // MARK: - PRIVATE
    private func updateView() {
        guard let viewModel = viewModel else { return }
        distanceLabel.text = viewModel.distance
        ratingLabel.text = viewModel.rating
        titleLabel.text = viewModel.title
        addressLabel.text = viewModel.address
        if viewModel.isFavorite == true {
            favoriteButton.setImage(UIImage(named: "thich"), for: .normal)
        }  else {
            favoriteButton.setImage(UIImage(named: "khongthich"), for: .normal)
        }
        avatarImageView.image = viewModel.image
    }
    
    // MARK: - ACTION
    @IBAction private func favoriteButtonTouchUpInside(_ sender: UIButton) {
        guard let viewModel = viewModel else { return }
        if viewModel.isFavorite == true {
            viewModel.isFavorite = false
            favoriteButton.setImage(UIImage(named: "khongthich"), for: .normal)
        } else {
            viewModel.isFavorite = true
            favoriteButton.setImage(UIImage(named: "thich"), for: .normal)
        }
    }
}
