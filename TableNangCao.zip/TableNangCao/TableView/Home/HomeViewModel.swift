//
//  HomeViewModel.swift
//  TableView
//
//  Created by PCI0010 on 12/25/18.
//  Copyright © 2018 Hai Nguyen H.P. All rights reserved.
//

import Foundation
import UIKit

final class HomeViewModel {
    
    // MARK: - PROPERTIES
    private var caffes: [Caffe] = []
    
    // MARK: - PUBLIC
    func getData() {
        return caffes = dummyData
    }
    
    func getCaffe(ofIndexPath indexPath: IndexPath) -> Caffe {
        return caffes[indexPath.row]
    }
    
    func numberOfRow(inSection section: Int) -> Int {
        return caffes.count
    }
    
    func viewModelForItem(atIndexPath indexPath: IndexPath) -> RestaurentCellViewModel {
        return RestaurentCellViewModel(caffe: caffes[indexPath.row])
    }
}

// MARK: - DUMMY DATA
extension HomeViewModel {
    var dummyData: [Caffe] {
        var caffes: [Caffe] = []
        
        let caffe = Caffe(image: UIImage(named: "cafe1"), title: "The Coffe house", address: "03 Nguyễn Văn Linh",rating: "9/10", distance: "5km", favorite: false)
        caffes.append(caffe)
        
        let caffe1 = Caffe(image: UIImage(named: "cafe2"), title: "Tocotoco", address: "13 Nguyễn Văn Linh", rating: "7/10", distance: "5km", favorite: false)
        caffes.append(caffe1)
        
        let caffe2 = Caffe(image: UIImage(named: "cafe3"), title: "GongCha", address: "05 Nguyễn Văn Linh",rating: "9/10", distance: "5km", favorite: false)
        caffes.append(caffe2)
        
        let caffe3 = Caffe(image: UIImage(named: "cafe4"), title: "Highland Coffe", address: "50 Bạch Đằng",rating: "9/10", distance: "4km", favorite: false)
        caffes.append(caffe3)
        
        let caffe4 = Caffe(image: UIImage(named: "cafe5"), title: "Cafe Vườn", address: "60 Ông Ích Khiêm",rating: "8/10", distance: "8km", favorite: false)
        caffes.append(caffe4)
        
        let caffe5 = Caffe(image: UIImage(named: "cafe6"), title: "RaFew Cafe", address: "16 Hoàng Văn Thụ",rating: "9/10", distance: "6km", favorite: false)
        caffes.append(caffe5)
        
        let caffe6 = Caffe(image: UIImage(named: "cafe7"), title: "Phúc Long", address: "11 Nguyen Van Linh",rating: "9/10", distance: "5km", favorite: false)
        caffes.append(caffe6)
        
        let caffe7 = Caffe(image: UIImage(named: "cafe7"), title: "Phúc Long", address: "11 Nguyen Van Linh",rating: "9/10", distance: "5km", favorite: false)
        caffes.append(caffe7)
        
        return caffes
    }
}
