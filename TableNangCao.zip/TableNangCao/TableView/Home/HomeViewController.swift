//
//  HomeViewController.swift
//  TableView
//

import UIKit

final class HomeViewController: UIViewController {
    
    // MARK: - OUTLET
    @IBOutlet private weak var scrollView: UIScrollView!
    @IBOutlet private weak var tableView: UITableView!
    @IBOutlet private weak var pageControl: UIPageControl!
    
    // MARK: - PROPERTIES
    private var homeViewModel = HomeViewModel()

    // MARK: - LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        configTableView()
        getData()
        configurePageControl()
        configScrollView()
    }

    // MARK: - PRIVATE
    private func configScrollView() {
        scrollView.delegate = self
    }

    private func configTableView() {
        let nib = UINib(nibName: "RestaurentCellTableViewCell", bundle: Bundle.main)
        tableView.register(nib, forCellReuseIdentifier: "RestaurentCellTableViewCell")
        tableView.dataSource = self
        tableView.delegate = self
        tableView.rowHeight = 100
    }
    
    private func getData() {
        homeViewModel.getData()
        tableView.reloadData()
    }
    
    private func configurePageControl() {
        self.pageControl.numberOfPages = 3
    }
    
    // MARK: - ACTION
    @IBAction private func backButtonTouchUpInside(_ sender: UIButton) {
        if scrollView.contentOffset.x > 0 {
            let contentOffsetX = scrollView.contentOffset.x - UIScreen.main.bounds.width
            let toado1 = CGPoint(x: contentOffsetX, y: 0)
            scrollView.setContentOffset(toado1, animated: true)
            pageControl.currentPage = pageControl.currentPage - 1
        }
    }

    @IBAction private func nextButtonTouchUpInside(_ sender: UIButton) {
        if scrollView.contentSize.width > scrollView.contentOffset.x + UIScreen.main.bounds.width {
            let contentOffsetY = scrollView.contentOffset.x + UIScreen.main.bounds.width
            let toado = CGPoint(x: contentOffsetY, y: 0)
            scrollView.setContentOffset(toado, animated: true)
            pageControl.currentPage = pageControl.currentPage + 1
        }
    }
}

// MARK: - UITableViewDataSource
extension HomeViewController: UITableViewDataSource {

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "RestaurentCellTableViewCell", for: indexPath)
        if let restaurantCell = cell as? RestaurentCellTableViewCell {
            let vm = homeViewModel.viewModelForItem(atIndexPath: indexPath)
            restaurantCell.viewModel = vm
        }
        return cell
    }
}

// MARK: - UITableViewDelegate
extension HomeViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let detail = DetailViewController()
        navigationController?.pushViewController(detail, animated: true)
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return homeViewModel.numberOfRow(inSection: section)
    }
}

// MARK: - UIScrollViewDelegate
extension HomeViewController: UIScrollViewDelegate {

    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let index = scrollView.contentOffset.x / UIScreen.main.bounds.width
        pageControl.currentPage = Int(index)
    }
}
