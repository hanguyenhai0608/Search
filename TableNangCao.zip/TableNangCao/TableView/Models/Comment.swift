//
//  comment.swift
//  TableView
//
//  Created by PCI0010 on 12/18/18.
//  Copyright © 2018 Hai Nguyen H.P. All rights reserved.
//

import Foundation
import UIKit

final class Comment {
    
    // MARK: - PROPERTIES
    var image: UIImage?
    var name: String = ""
    var dayText: String = ""
    var comment: String = ""
    
    // MARK: - INIT
    init(image: UIImage?, name: String, dayText: String, comment: String) {
        self.image = image
        self.name = name
        self.dayText = dayText
        self.comment = comment
    }
}
