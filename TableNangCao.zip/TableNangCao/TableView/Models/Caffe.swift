//
//  caffe.swift
//  TableView
//

import Foundation
import UIKit

final class Caffe {

    // MARK: - PROPERTIES
    var image: UIImage?
    var title: String = ""
    var address: String = ""
    var rating: String = ""
    var distance: String = ""
    var isFavorite: Bool

    // MARK: - INIT
    init(image: UIImage?, title: String, address: String, rating: String, distance: String, favorite: Bool) {
        self.image = image
        self.title = title
        self.address = address
        self.rating = rating
        self.distance = distance
        self.isFavorite = favorite
    }
}
