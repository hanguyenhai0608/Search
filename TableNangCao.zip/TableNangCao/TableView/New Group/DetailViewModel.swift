//
//  DetailViewModel.swift
//  TableView
//
//  Created by PCI0010 on 12/25/18.
//  Copyright © 2018 Hai Nguyen H.P. All rights reserved.
//

import Foundation
import UIKit

final class DetailViewModel {
    
    // MARK: - PROPERTIES
    var comments: [Comment] = []
    
    // MARK: - PUBLIC
    func getData() {
        return comments = dummyData
    }
    
    func getCaffe(ofIndexPath indexPath: IndexPath) -> Comment {
        return comments[indexPath.row]
    }
    
    func numberOfRow(inSection section: Int) -> Int {
        return comments.count
    }
    
    func viewModelForItem(atIndexPath indexPath: IndexPath) -> CommentCellViewModel {
        return CommentCellViewModel(comment: comments[indexPath.row])
    }
}

// MARK: - DUMMY DATA
extension DetailViewModel {
    
    var dummyData: [Comment] {
        var comments: [Comment] = []
        
        let comment = Comment(image: UIImage(named: "avatar1"), name: "Hải Hà", dayText: "16 days ago", comment: "Lâu rồi mới order lại Highlands. Như mọi khi gọi 2 món best sale của quán là freeze matcha và freeze chocolate. Nước ngon, chocolate uống vào đọng lại vị đắng chứ không ngọt gắt, matcha thơm. Mình thích nhất lớp kem tươi ở trên, béo béo thơm chứ không nọt, uống mãi không ngán chút nào.")
        comments.append(comment)
        
        let comment1 = Comment(image: UIImage(named: "avatar2"), name: "Trọng Quế", dayText: "4 days ago", comment: "Thạch thì giòn, vải thì ngọt và mát . Bánh trà xanh thì mềm và ngọt. Không gian rộng rãi và thoáng mát. Trang trí đẹp. Còn có máy lạnh nữa . Nhân viên phục vụ rất tốt , nhiệt tình và thân thiện. Khách tới rất đông. Lâu lâu lại có phiếu giảm giá nữa . Rất thích máy thông báo có món . Rất tuyệt! Khi có món nó đỏ đèn và rung lên. Phục vụ món rất nhanh . Còn có rất nhiều món tráng miệng như bánh . Buổi sáng còn có cả bánh mì nữa. ")
        comments.append(comment1)
        
        let comment2 = Comment(image: UIImage(named: "avatar3"), name: "Thuý Lưu", dayText: "4 days ago", comment: "Hôm nay thứ bảy được nghỉ cuối tuần. Mình rủ một số người bạn đi đâu uống coffee. Nhớ lại quán Highlands Coffee ở indochina nên quyết định đến đây. Mình đã thử nhiều quán Highlands trong cùng hệ thống. Nhưng chỉ có nước ở đây là ngon và chuẩn nhất. Bánh cũng rất ngon. Nhất là Tỉamisu. Không gian ở đây thì khỏi phải nói. Phù hợp với mọi lứa tuổi. Nhất là vừa uống coffee vừa ngắm sông hàn về đêm. Thật là đỉnh của đỉnh! Nhưng ở đây mình thích nhất là ngồi bao lâu cũng được và nhân viên rất thân thiện. ")
        comments.append(comment2)
        
        return comments
    }
}
