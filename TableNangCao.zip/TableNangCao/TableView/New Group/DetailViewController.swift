//
//  DetailViewController.swift
//  TableView
//
//  Created by PCI0010 on 12/18/18.
//  Copyright © 2018 Hai Nguyen H.P. All rights reserved.
//

import UIKit

final class DetailViewController: UIViewController {
    
    // MARK: - OUTLET
    @IBOutlet private weak var tableView: UITableView!
    @IBOutlet private weak var pageControl: UIPageControl!
    @IBOutlet private weak var scrollView: UIScrollView!
    
    // MARK: - PROPERTIES
    var detailViewModel = DetailViewModel()
    
    // MARK: - LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        getData()
        sizeHeaderToFit()
        configDetailView()
        configurePageControl()
        configScrollView()
    }
    
    // MARK: - PRIVATE
    private func sizeHeaderToFit() {
        let headerView = tableView.tableHeaderView!
        headerView.setNeedsLayout()
        headerView.layoutIfNeeded()
        let height = headerView.systemLayoutSizeFitting(UIView.layoutFittingCompressedSize).height
        var frame = headerView.frame
        frame.size.height = height
        headerView.frame = frame
        tableView.tableHeaderView = headerView
    }
    
    private func configDetailView() {
        let nib = UINib(nibName: "CommentTableViewCell", bundle: Bundle.main)
        tableView.register(nib, forCellReuseIdentifier: "CommentTableViewCell")
        tableView.dataSource = self
    }
    
    private func configurePageControl() {
        self.pageControl.numberOfPages = 3
    }
    
    private func configScrollView() {
        scrollView.delegate = self
    }
    
    private func getData() {
        detailViewModel.getData()
    }
    
    // MARK: - ACTION
    @IBAction private func backButtonTouchUpInside(_ sender: UIButton) {
        if scrollView.contentOffset.x > 0 {
            let contentOffset = scrollView.contentOffset.x - UIScreen.main.bounds.width
            let toado1 = CGPoint(x: contentOffset, y: 0)
            scrollView.setContentOffset(toado1, animated: true)
            pageControl.currentPage = pageControl.currentPage - 1
        }
    }
    
    @IBAction private func nextButtonTouchUpInside(_ sender: UIButton) {
        if scrollView.contentSize.width > scrollView.contentOffset.x + UIScreen.main.bounds.width {
            let contentOffset = scrollView.contentOffset.x + UIScreen.main.bounds.width
            let toado = CGPoint(x: contentOffset, y: 0)
            scrollView.setContentOffset(toado, animated: true)
            pageControl.currentPage = pageControl.currentPage + 1
        }
    }
}

// MARK: - UIScrollViewDelegate
extension DetailViewController: UIScrollViewDelegate {
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let index = scrollView.contentOffset.x / UIScreen.main.bounds.width
        pageControl.currentPage = Int(index)
    }
}

// MARK: - UITableViewDataSource
extension DetailViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return detailViewModel.numberOfRow(inSection: section)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CommentTableViewCell", for: indexPath)
        if let commentCell = cell as? CommentTableViewCell {
            let vm = detailViewModel.viewModelForItem(atIndexPath: indexPath)
            commentCell.viewModel = vm
        }
        return cell
    }
}
