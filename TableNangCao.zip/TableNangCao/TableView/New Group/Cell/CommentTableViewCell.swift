//
//  CommentTableViewCell.swift
//  TableView
//
//  Created by PCI0010 on 12/18/18.
//  Copyright © 2018 Hai Nguyen H.P. All rights reserved.
//

import UIKit

final class CommentTableViewCell: UITableViewCell {
    
    // MARK: - OUTLET
    @IBOutlet private weak var commentLabel: UILabel!
    @IBOutlet private weak var dayLabel: UILabel!
    @IBOutlet private weak var nameLabel: UILabel!
    @IBOutlet private weak var avatarImageView: UIImageView!
    
    // MARK: - LIFE CYCLE
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    // MARK: - PROPERTIES
    var viewModel: CommentCellViewModel? {
        didSet {
            updateView()
        }
    }
    
    // MARK: - PRIVATE
    private func updateView() {
        guard let viewModel = viewModel else { return }
        dayLabel.text = viewModel.day
        nameLabel.text = viewModel.name
        commentLabel.text = viewModel.cmt
        avatarImageView.image = viewModel.image
    }
}
