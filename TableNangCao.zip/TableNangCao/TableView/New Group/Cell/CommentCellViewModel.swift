//
//  CommentCellViewModel.swift
//  TableView
//
//  Created by PCI0010 on 12/25/18.
//  Copyright © 2018 Hai Nguyen H.P. All rights reserved.
//

import Foundation
import UIKit

final class CommentCellViewModel {

    // MARK: - PROPERTIES 
    var comment: Comment?
    var image: UIImage?
    var day = ""
    var name = ""
    var cmt = ""
    
    // MARK: - INIT
    init(comment: Comment) {
        self.comment = comment
        day = comment.dayText
        name = comment.name
        cmt = comment.comment
        image = comment.image
    }
}
